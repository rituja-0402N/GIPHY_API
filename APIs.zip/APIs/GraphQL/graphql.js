//Star Wars GRAPHQL

fetch("https://swapi-graphql.netlify.app/.netlify/functions/index?query={allFilms{films{title}}}")
.then(function (response) {
  return response.json();
})
.then(function(respJson){
  console.log(respJson);
})
