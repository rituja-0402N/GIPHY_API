//GIPHY API - Random Endpoints

fetch("https://api.giphy.com/v1/gifs/random?api_key=41FMemYeHMyERNS1wQHe5vnEUKNlC38j&tag=bird&rating=g")
.then(function(response){
	return response.json();
})
.then(function(respJson){
	console.log(respJson);
	var gifUrl = respJson.data.images.original.url;
	console.log(gifUrl);
	var gifImg = document.createElement("img");
	gifImg.setAttribute("src",gifUrl);
	document.body.appendChild(gifImg);
})

fetch("https://api.giphy.com/v1/gifs/random?api_key=41FMemYeHMyERNS1wQHe5vnEUKNlC38j&tag=sea+otter&rating=g")
.then(function(response){
	if(response.status == 200){
			return response.json();
	}
	else{
		console.log("Whoops Problem!!")
	}

})
.then(function(respJson){
	console.log(respJson);
	//Display title
	var title = respJson.data.title;
	var itemTitle = document.createElement("h1");
	itemTitle.innerHTML = title;
	document.body.appendChild(itemTitle);

//Create GIF on page
	var gifUrl = respJson.data.images.original.url;
	console.log(gifUrl);
	var gifImg = document.createElement("img");
	gifImg.setAttribute("src",gifUrl);
	document.body.appendChild(gifImg);
})
.catch(function(error){
	console.log("There was a problem" ,error);
})
